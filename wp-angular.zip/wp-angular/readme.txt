=== Twenty Fifteen ===
Contributors: Yannick Roffin
Tags: angularjs angularmd
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 4.1
License: Apache License Version 2.0 
License URI: http://www.apache.org/licenses/LICENSE-2.0

== Description ==
Simple angularjs wordpress theme.

* Responsive Layout
* Social behaviour (facebook)
* Need wp-json api to be setup
* Workstation side handle for each contents
* Apache License Version 2.0

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= How do I change background image ? =

You can change the background image in customizer.

= Quick Specs =

1. TODO.
